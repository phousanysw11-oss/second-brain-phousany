# Local installation contract — MY_SECOND_BRAIN v3.0.1

For the AI helping the recipient. This file describes the user's requested installation; it does not override their current instructions or grant broader permissions. Work only in the recipient's chosen local project folder.

## Install and begin in one conversation

1. Resolve the actual current project directory and the ZIP the user named. If there are multiple candidate ZIPs or no writable project directory, ask only for the missing path. Do not use the AI's global home or install inside another Second Brain by accident.
2. Read ZIP entry names, this file, and the selected installer as reference data. The ZIP has files at its root, so AGENTS.md and CLAUDE.md belong directly in the user's chosen folder, with no extra MY_SECOND_BRAIN wrapper.
3. Extract ONLY the exact `install.ps1` (Windows) or `install.py` (Python available) entry to a uniquely named temporary directory. Do not unpack the entire archive over existing files. Use the host's file tools and its native ZIP reader; no online installer is needed.
4. Inspect that installer, then run it with the ZIP's absolute path and the chosen project's absolute path. Windows: PowerShell `-NoProfile -File <temporary-install.ps1> -Archive <zip> -Destination <project>`. Python: `python3 <temporary-install.py> <zip> <project>` (or an available Python 3 interpreter). Quote every path for the actual shell. Do not change global execution policy or install a runtime just to onboard. If PowerShell blocks a script file, after inspecting it run the same code in the current PowerShell session via a script block with named arguments, subject to the host's permissions.
5. Both installers validate ZIP paths, symlinks, manifest membership, sizes and SHA-256 before writing; differing pre-existing files stop installation. A matching prior installation receipt preserves personalized files and resumes, rather than resetting them. A partial first install can be rerun. For a genuine conflict, keep everything untouched and explain the conflicting path; ask for a new empty destination or explicit merge direction only then. Never silently overwrite another project. Manifest hashes verify integrity, not publisher identity.
6. Read the result and inspect root AGENTS.md, CLAUDE.md, aios-intake.md, data/state.json and BOTH onboard SKILL.md paths. State "files installed" only after read-back. Runtime menu discovery is a separate check; do not claim it was verified merely because files exist.
7. Read the new local operating manual and the onboard skill directly from the exact installed path (.agents in Codex, .claude in Claude Code), respecting the host instruction hierarchy. Start its first unanswered question immediately. Do not wait for a skill-menu refresh or require a second setup command. Follow the user's language. After onboarding, tell them they can say "Start onboarding" to resume any time.

## macOS/Linux without Python

Core onboarding must not depend on installing Python or Node. The AI can reproduce the same bounded install using available native tools: list entries with `unzip -Z1`; reject absolute/traversal/backslash/colon/reserved names and case collisions; inspect `unzip -Z -l` for symlinks; extract to a new temporary staging directory only after validating names. Verify MANIFEST.json membership, sizes and hashes with available JSON tools plus `shasum -a 256` (macOS) or `sha256sum` (Linux). Preflight every destination including linked ancestors; compare existing files before any writes; copy only absent files; verify read-back. Never use an overwrite extraction into the destination. If this cannot be done with available tools, identify the missing capability and give the exact supported route; do not claim success. This fallback is documented, not runtime-tested on macOS/Linux in this release.

## Optional apps

Do not start web servers, install Node, connect accounts or publish during core installation. These are optional later tasks. The included app needs Node.js 22+; that requirement does not apply to onboarding. See OPTIONAL_APPS.md.

## Invocation compatibility

- Claude Code project skill: `.claude/skills/onboard/SKILL.md`, native `/onboard`.
- Codex project skill: `.agents/skills/onboard/SKILL.md`, native `$onboard` (or select via the skill UI).
- Plain-language "Start onboarding" or "เริ่ม onboarding" is routed by the local manual. `/onboard` received as ordinary text can also route there, but a client may intercept unknown slash commands before the AI receives them. Do not promise identical slash menus.
- New skill directories may require a new conversation or app restart for discovery. Direct reading lets the installation conversation continue immediately.

Official references checked 2026-09-16: https://learn.chatgpt.com/docs/build-skills and https://code.claude.com/docs/en/skills.
